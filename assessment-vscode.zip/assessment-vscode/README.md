# 第一單元評量網站 · VS Code 專案

這是獨立的 HTML、CSS、JavaScript 網站，無須安裝套件、無須登入，也沒有雲端服務依賴。

## 直接開啟

雙擊 **開啟評量.cmd**，或用瀏覽器開啟 **public/index.html**，即可作答。所有畫面與題庫都在本機，離線也能使用。

進度會嘗試儲存在目前瀏覽器。若瀏覽器限制本機檔案的儲存權限，畫面會明確提示；也可以使用下面的本機伺服器方式。不同瀏覽器或不同開啟網址的進度各自獨立。

## 用 VS Code 開發與預覽

1. 用 VS Code 開啟本資料夾。
2. 電腦需有 Node.js 20 或更新版本。專案不需要 `npm install`。
3. 在終端機執行 `npm start`，開啟 http://127.0.0.1:4310 。
4. 或按 F5，選擇「開啟評量網站（Edge）」；已安裝 Chrome 也可選 Chrome 設定。
5. 終端機按 Ctrl+C 即可停止伺服器。

若已經啟動伺服器，直接開啟網址即可；不要同時啟動第二個伺服器。

## 修改內容

- 題目、選項、答案、提示、單元編號與通關密碼：`public/questions.js`。
- `answer` 使用 0 起算：A = 0、B = 1、C = 2、D = 3。
- 第一單元標準答案：**B、C、C、B、D、C、C、B、D、C**。
- 目前完成密碼為使用者指定的 **`*****`**。
- 畫面結構：`public/index.html`。
- 外觀與手機排版：`public/styles.css`。
- 作答進度與判定：`public/quiz-core.js`；畫面互動：`public/app.js`。
- 使用者附的提示表屬於營養課程，與題庫不同；此版提示依數位店員題目另寫。

題庫內容或標準答案改變後，會使用新的進度紀錄，避免舊進度誤套新題目。

## 修改後的驗收

先執行 `npm test`，再依 `AGENTS.md` 規則實際開啟網站、完成十題。實測記錄請見 `QA-REPORT.md`。

此專案是教學練習網站，答案與完成密碼包含在前端檔案。若未來要用於正式考試或保密通關，需另外加入伺服器驗證。

## GitHub Pages 公開網址

專案包含 `.github/workflows/pages.yml`。它會在推送至 `main` 後先執行測試，成功才發布 `public/` 內的網站。

初次發布時，在 GitHub 儲存庫的 **Settings → Pages → Build and deployment → Source** 選擇 **GitHub Actions**。完成部署後，以 GitHub Pages 顯示的網址分享給學員，即可直接作答，不需登入。

VS Code 的原始碼、測試與說明保留在儲存庫中；Pages 僅發布網站所需檔案。
