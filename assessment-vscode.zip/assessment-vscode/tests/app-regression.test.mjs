import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const [html, questionsSource, coreSource, appSource] = await Promise.all([
  readFile(new URL('../public/index.html', import.meta.url), 'utf8'),
  readFile(new URL('../public/questions.js', import.meta.url), 'utf8'),
  readFile(new URL('../public/quiz-core.js', import.meta.url), 'utf8'),
  readFile(new URL('../public/app.js', import.meta.url), 'utf8')
]);

// This small DOM double runs the actual app and its event handlers. It is not a
// layout/browser substitute: the full assessment still needs a browser check.
function createApp({ hash = '#chapters', storageUnavailable = false } = {}) {
  const elements = new Map();
  const windowListeners = new Map();
  const storage = new Map();
  const writes = [];
  let activeElement = null;

  class Element {
    constructor(tagName = 'div') {
      this.tagName = tagName.toUpperCase();
      this.children = [];
      this.dataset = {};
      this.style = {};
      this.attributes = new Map();
      this.listeners = new Map();
      this.hidden = false;
      this.disabled = false;
      this.open = false;
      this.returnValue = '';
      this.className = '';
      this.ownText = '';
    }
    set textContent(value) { this.ownText = String(value); this.children = []; }
    get textContent() { return this.ownText + this.children.map(child => child.textContent).join(''); }
    append(...children) {
      this.children.push(...children.map(child => typeof child === 'string' ? { textContent: child } : child));
    }
    replaceChildren(...children) { this.children = []; this.ownText = ''; this.append(...children); }
    setAttribute(name, value) { this.attributes.set(name, String(value)); }
    getAttribute(name) { return this.attributes.get(name) ?? null; }
    addEventListener(name, listener) {
      if (!this.listeners.has(name)) this.listeners.set(name, []);
      this.listeners.get(name).push(listener);
    }
    dispatch(name, fields = {}) {
      for (const listener of this.listeners.get(name) ?? []) listener({ target: this, currentTarget: this, ...fields });
    }
    click() { if (!this.disabled) this.dispatch('click'); }
    focus() { activeElement = this; }
    scrollIntoView() {}
    showModal() { this.open = true; }
    close() { this.open = false; this.dispatch('close'); }
  }

  // Only IDs that exist in the real HTML are available to the app.
  for (const match of html.matchAll(/<([a-z][\w-]*)\b[^>]*\bid="([^"]+)"[^>]*>/gi)) {
    elements.set(match[2], new Element(match[1]));
  }
  const element = id => {
    const found = elements.get(id);
    assert.ok(found, `the real HTML must contain #${id}`);
    return found;
  };
  const localStorage = {
    getItem(key) {
      if (storageUnavailable) throw new Error('storage access blocked');
      return storage.get(String(key)) ?? null;
    },
    setItem(key, value) {
      if (storageUnavailable) throw new Error('storage access blocked');
      key = String(key); value = String(value);
      storage.set(key, value);
      writes.push({ key, value });
    },
    removeItem(key) {
      if (storageUnavailable) throw new Error('storage access blocked');
      storage.delete(String(key));
    }
  };
  const document = {
    title: '',
    get activeElement() { return activeElement; },
    getElementById: id => elements.get(id) ?? null,
    createElement: tagName => new Element(tagName),
    createTextNode: textContent => ({ textContent: String(textContent) })
  };
  const context = vm.createContext({
    document,
    location: { hash },
    localStorage,
    matchMedia: () => ({ matches: false }),
    navigator: { clipboard: { writeText: async () => {} } },
    addEventListener(name, listener) {
      if (!windowListeners.has(name)) windowListeners.set(name, []);
      windowListeners.get(name).push(listener);
    }
  });
  context.window = context;
  for (const [filename, source] of [
    ['questions.js', questionsSource], ['quiz-core.js', coreSource], ['app.js', appSource]
  ]) vm.runInContext(source, context, { filename });

  function dispatch(name, event) {
    for (const listener of windowListeners.get(name) ?? []) listener(event);
  }
  return {
    catalog: context.QuizCatalog,
    storage,
    writes,
    element,
    keyFor(chapter) {
      return `${chapter.id}:${JSON.stringify(chapter.questions.map(question => [question.question, question.options, question.answer]))}`;
    },
    navigate(nextHash) {
      context.location.hash = nextHash;
      dispatch('hashchange', { newURL: `https://example.test/quiz/${nextHash}` });
    },
    // Simulate a different tab committing data before this tab receives the
    // browser's storage event. The external write must not count as an app write.
    externalWrite(key, value) {
      const oldValue = storage.get(key) ?? null;
      const newValue = value === null ? null : JSON.stringify(value);
      if (newValue === null) storage.delete(key);
      else storage.set(key, newValue);
      dispatch('storage', { key, oldValue, newValue, storageArea: localStorage, url: 'https://example.test/quiz/' });
    },
    choose(option) { element('options').children[option].click(); },
    next() { element('next').click(); },
    saved(chapter) { return JSON.parse(storage.get(this.keyFor(chapter))); }
  };
}

function progressFor(chapter, index, mistakes = []) {
  return {
    index,
    answers: chapter.questions.slice(0, index).map(question => question.answer),
    mistakes
  };
}

function assertQuestion(app, chapter, index, completed = index) {
  assert.equal(app.element('question-title').textContent, chapter.questions[index].question);
  assert.equal(app.element('question-counter').textContent, `QUESTION ${String(index + 1).padStart(2, '0')} / 10`);
  assert.equal(Number(app.element('completed-count').textContent), completed);
}

test('another tab updates a chapter cached by the picker without losing its saved progress', () => {
  const app = createApp();
  const chapter = app.catalog[1];
  const externalProgress = progressFor(chapter, 3);
  assert.equal(app.element('chapter-cards').children.length, 4);

  app.externalWrite(app.keyFor(chapter), externalProgress);
  assert.equal(app.writes.length, 0, 'a storage event must not write data back to the other tab');
  assert.match(app.element('chapter-cards').children[1].textContent, /已答對 3 \/ 10 題/);
  app.navigate('#chapter-2');

  assertQuestion(app, chapter, 3);
  assert.deepEqual(app.saved(chapter), JSON.parse(JSON.stringify(externalProgress)));
  app.choose(chapter.questions[3].answer);
  app.next();
  assertQuestion(app, chapter, 4);
  assert.deepEqual(app.saved(chapter), JSON.parse(JSON.stringify(progressFor(chapter, 4))));
});

test('an active chapter adopts another tab progress and clears feedback from its previous question', () => {
  const app = createApp({ hash: '#chapter-1' });
  const chapter = app.catalog[0];
  app.choose(0); // A wrong first answer leaves local feedback that must be replaced.
  const beforeEventWrites = app.writes.length;
  const externalProgress = progressFor(chapter, 3, [{ question: 3, option: 2 }]);

  app.externalWrite(app.keyFor(chapter), externalProgress);

  assert.equal(app.writes.length, beforeEventWrites, 'external progress should render without another storage write');
  assertQuestion(app, chapter, 3);
  assert.match(app.element('feedback').textContent, /C 是錯誤選項/);
  assert.equal(app.element('next').disabled, true);
  app.choose(chapter.questions[3].answer);
  app.next();
  assertQuestion(app, chapter, 4);
  assert.equal(app.saved(chapter).index, 4);
  assert.deepEqual(app.saved(chapter).answers, JSON.parse(JSON.stringify(chapter.questions.slice(0, 4).map(question => question.answer))));
});

test('unrelated storage keys leave the active chapter and its cached progress untouched', () => {
  const app = createApp({ hash: '#chapter-1' });
  const chapter = app.catalog[0];
  app.choose(chapter.questions[0].answer);
  app.next();
  app.choose(0);
  const beforeEventWrites = app.writes.length;
  const feedbackBefore = app.element('feedback').textContent;
  const savedBefore = app.saved(chapter);

  app.externalWrite('unrelated-site-preferences', { index: 9, answers: ['not quiz progress'] });

  assert.equal(app.writes.length, beforeEventWrites);
  assertQuestion(app, chapter, 1);
  assert.equal(app.element('feedback').textContent, feedbackBefore);
  assert.deepEqual(app.saved(chapter), savedBefore);
  app.navigate('#chapters');
  app.navigate('#chapter-1');
  assertQuestion(app, chapter, 1);
  assert.equal(app.element('feedback').textContent, feedbackBefore);
});

test('blocked storage keeps separate chapter progress and wrong answers in memory while switching chapters', () => {
  const app = createApp({ storageUnavailable: true });
  const [chapterOne, chapterTwo] = app.catalog;
  app.navigate('#chapter-1');
  app.choose(chapterOne.questions[0].answer);
  app.next();
  app.choose(0); // First chapter: question two is unsolved, with A marked wrong.

  app.navigate('#chapter-2');
  assertQuestion(app, chapterTwo, 0);
  for (let index = 0; index < 2; index += 1) {
    app.choose(chapterTwo.questions[index].answer);
    app.next();
  }
  app.choose(1); // Second chapter: question three has B marked wrong.
  app.navigate('#chapter-1');

  assertQuestion(app, chapterOne, 1);
  assert.match(app.element('feedback').textContent, /A 是錯誤選項/);
  assert.match(app.element('storage-status').textContent, /無法儲存/);
  app.choose(chapterOne.questions[1].answer);
  app.next();
  app.navigate('#chapter-2');
  assertQuestion(app, chapterTwo, 2);
  assert.match(app.element('feedback').textContent, /B 是錯誤選項/);
  assert.equal(app.writes.length, 0);
  assert.equal(app.storage.size, 0);

  // Reset the second chapter and ensure only its in-memory record is cleared.
  app.element('restart').click();
  app.element('restart-dialog').returnValue = 'restart';
  app.element('restart-dialog').close();
  assertQuestion(app, chapterTwo, 0);
  app.navigate('#chapter-1');
  assertQuestion(app, chapterOne, 2);
});
