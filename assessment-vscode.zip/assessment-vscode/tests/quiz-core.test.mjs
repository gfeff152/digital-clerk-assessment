import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../public/quiz-core.js', import.meta.url), 'utf8');
const context = vm.createContext({});
vm.runInContext(source, context, { filename: 'quiz-core.js' });
const { initialState, restoreState, choose, next } = context.QuizCore;
const answers = [1, 2, 2, 1, 3, 2, 2, 1, 3, 2];
const questions = answers.map(answer => ({ options: ['A', 'B', 'C', 'D'], answer }));
const plain = value => JSON.parse(JSON.stringify(value));
const snapshot = state => JSON.stringify(state);

test('real question bank contains ten complete four-option questions and the supplied answer key', async () => {
  const dataContext = vm.createContext({});
  const dataSource = await readFile(new URL('../public/questions.js', import.meta.url), 'utf8');
  vm.runInContext(dataSource, dataContext, { filename: 'questions.js' });
  const quiz = dataContext.QuizData;
  assert.equal(quiz.number, 1);
  assert.equal(quiz.password, '*****');
  assert.equal(typeof quiz.id, 'string');
  assert.ok(quiz.id.length > 0);
  assert.equal(quiz.questions.length, 10);
  assert.deepEqual(plain(quiz.questions.map(question => question.answer)), answers);
  let state = initialState();
  for (let index = 0; index < quiz.questions.length; index += 1) {
    const question = quiz.questions[index];
    assert.equal(question.options.length, 4, `question ${index + 1} must have four options`);
    assert.equal(new Set(question.options).size, 4);
    for (const value of [question.question, ...question.options, question.hint, question.explanation]) {
      assert.equal(typeof value, 'string');
      assert.ok(value.trim().length > 0, `question ${index + 1} has an empty field`);
    }
    const chosen = choose(state, quiz.questions, answers[index], index);
    assert.equal(chosen.result, 'correct');
    state = next(chosen.state, quiz.questions, index);
  }
  assert.equal(state.index, 10);
  assert.equal(state.answers.length, 10);
});

test('classic script exposes only the required, frozen API', () => {
  assert.deepEqual(Object.keys(context.QuizCore).sort(), ['choose', 'initialState', 'next', 'restoreState']);
  assert.ok(Object.isFrozen(context.QuizCore));
  const first = initialState();
  const second = initialState();
  assert.deepEqual(plain(first), { index: 0, answers: [], mistakes: [] });
  first.answers.push(1);
  assert.equal(second.answers.length, 0);
});

test('malformed stored values start safely at question one', () => {
  const malformed = [null, undefined, false, 7, '{bad JSON', [], {},
    { index: -1, answers }, { index: 11, answers }, { index: 0.5, answers },
    { index: '3', answers }, { index: NaN, answers }, { index: 2, answers: 'BC' },
    { answers }];
  for (const saved of malformed) {
    assert.deepEqual(plain(restoreState(saved, questions)), plain(initialState()));
  }
});

test('restore rejects gaps, incorrect prefixes, and forged index-only progress', () => {
  assert.deepEqual(plain(restoreState({ index: 8, answers: [], mistakes: [] }, questions)), plain(initialState()));
  assert.deepEqual(plain(restoreState({ index: 7, answers: [1, 0, 2, 1], mistakes: [] }, questions)),
    { index: 1, answers: [1], mistakes: [] });
  const sparse = [1, , 2];
  assert.deepEqual(plain(restoreState({ index: 3, answers: sparse, mistakes: [] }, questions)),
    { index: 1, answers: [1], mistakes: [] });
  assert.deepEqual(plain(restoreState({ index: 0, answers, mistakes: [] }, questions)),
    { index: 0, answers: [1], mistakes: [] });
});

test('restore keeps only unique wrong options from already reached questions', () => {
  const saved = { index: 4, answers: [1], mistakes: [
    { question: 0, option: 0 }, { question: 0, option: 0 },
    { question: 1, option: 3 }, { question: 2, option: 0 },
    { question: 0, option: 1 }, { question: -1, option: 0 },
    { question: 1, option: 4 }, { question: '0', option: 2 },
    null, false, {}, { question: 1, option: 1 }
  ] };
  assert.deepEqual(plain(restoreState(saved, questions)), {
    index: 1, answers: [1], mistakes: [
      { question: 0, option: 0 }, { question: 1, option: 3 }, { question: 1, option: 1 }
    ]
  });
  assert.equal(saved.mistakes.length, 12);
});

test('refresh preserves unanswered, wrong, correct-awaiting-next, and finished states', () => {
  let state = initialState();
  const verify = () => assert.deepEqual(plain(restoreState(JSON.parse(snapshot(state)), questions)), plain(state));
  verify();
  state = choose(state, questions, 0).state;
  verify();
  for (let index = 0; index < questions.length; index += 1) {
    state = choose(state, questions, answers[index], index).state;
    verify();
    assert.equal(state.index, index);
    state = next(state, questions, index);
    verify();
  }
  assert.equal(state.index, 10);
});

test('thirty wrong answers still require all ten correct answers before completion', () => {
  let state = initialState();
  let wrongCount = 0;
  for (let index = 0; index < questions.length; index += 1) {
    for (let option = 0; option < 4; option += 1) {
      if (option === answers[index]) continue;
      const chosen = choose(state, questions, option, index);
      assert.equal(chosen.result, 'wrong');
      state = chosen.state;
      wrongCount += 1;
      assert.equal(state.index, index);
      assert.equal(state.answers.length, index);
      assert.strictEqual(next(state, questions, index), state);
    }
    const chosen = choose(state, questions, answers[index], index);
    assert.equal(chosen.result, 'correct');
    state = chosen.state;
    assert.equal(state.index, index);
    state = next(state, questions, index);
  }
  assert.equal(wrongCount, 30);
  assert.equal(state.mistakes.length, 30);
  assert.equal(state.index, 10);
  assert.deepEqual(plain(state.answers), answers);
});

test('rapid repeated wrong choices are deduplicated and remain answerable', () => {
  let state = initialState();
  for (let click = 0; click < 30; click += 1) {
    const chosen = choose(state, questions, 0, 0);
    assert.equal(chosen.result, 'wrong');
    state = chosen.state;
  }
  assert.equal(state.mistakes.length, 1);
  assert.equal(choose(state, questions, 1, 0).result, 'correct');
});

test('double correct click cannot record twice or accept another choice after passing', () => {
  const passed = choose(initialState(), questions, 1, 0).state;
  for (const option of [1, 0, 3]) {
    const chosen = choose(passed, questions, option, 0);
    assert.equal(chosen.result, 'ignored');
    assert.strictEqual(chosen.state, passed);
  }
  assert.equal(passed.answers.length, 1);
});

test('double next and late events from an earlier question cannot skip a question', () => {
  const passed = choose(initialState(), questions, 1, 0).state;
  const current = next(passed, questions, 0);
  assert.equal(current.index, 1);
  assert.strictEqual(next(current, questions, 0), current);
  assert.strictEqual(next(current, questions, 1), current);
  assert.equal(choose(current, questions, 2, 0).result, 'ignored');
  assert.equal(current.answers.length, 1);
  const passedSecond = choose(current, questions, 2, 1).state;
  assert.strictEqual(next(passedSecond, questions, 0), passedSecond);
  assert.equal(next(passedSecond, questions, 1).index, 2);
});

test('invalid options and forged live states cannot bypass the current question', () => {
  const state = initialState();
  for (const option of [-1, 4, '1', null, undefined, 1.5, NaN]) {
    assert.equal(choose(state, questions, option).result, 'ignored');
  }
  const forged = [
    { index: -1, answers: [], mistakes: [] },
    { index: 5, answers: [], mistakes: [] },
    { index: 1, answers: [0], mistakes: [] },
    { index: 0, answers: [1, 2], mistakes: [] },
    { index: 10, answers: [], mistakes: [] },
    { index: 0, answers: [], mistakes: [{ question: 5, option: 0 }] }
  ];
  for (const candidate of forged) {
    assert.equal(choose(candidate, questions, 1).result, 'ignored');
    assert.strictEqual(next(candidate, questions), candidate);
  }
});

test('completed assessment ignores every further action', () => {
  const state = restoreState({ index: 10, answers, mistakes: [] }, questions);
  for (const option of [0, 1, 2, 3]) {
    const chosen = choose(state, questions, option, 10);
    assert.equal(chosen.result, 'ignored');
    assert.strictEqual(chosen.state, state);
  }
  assert.strictEqual(next(state, questions, 10), state);
});

test('valid transitions and restore never mutate their inputs', () => {
  const start = initialState();
  const before = snapshot(start);
  const wrong = choose(start, questions, 0).state;
  assert.equal(snapshot(start), before);
  const wrongBefore = snapshot(wrong);
  const correct = choose(wrong, questions, 1).state;
  assert.equal(snapshot(wrong), wrongBefore);
  const correctBefore = snapshot(correct);
  next(correct, questions);
  restoreState(correct, questions);
  assert.equal(snapshot(correct), correctBefore);
});

test('invalid question data cannot manufacture a completed assessment', () => {
  for (const invalid of [null, [], new Array(2), [{ answer: 0 }], [{ options: ['A'], answer: 1 }]]) {
    const state = initialState();
    assert.deepEqual(plain(restoreState({ index: 0, answers: [] }, invalid)), plain(state));
    assert.equal(choose(state, invalid, 0).result, 'ignored');
    assert.strictEqual(next(state, invalid), state);
  }
});
